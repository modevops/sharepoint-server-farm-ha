#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration ConfigureSharePointServerHA
{

    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointSetupUserAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmPassphrasecreds,

        [parameter(Mandatory)]
        [String]$DatabaseName,

        [parameter(Mandatory)]
        [String]$AdministrationContentDatabaseName,

        [parameter(Mandatory)]
        [String]$DatabaseServer,

        [parameter(Mandatory)]
        [String]$Configuration,

        [String]$SqlAlwaysOnAvailabilityGroupName,
        [String]$sharepointWebfqdn,
        [String]$sharepointFarmName,
        [String]$contentDatabaseName,
        
        [String[]]$DatabaseNames,

        [String]$PrimaryReplica,

        [String]$SecondaryReplica,

        [System.Management.Automation.PSCredential]$SQLServiceCreds,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60
    )

        Write-Verbose "AzureExtensionHandler loaded continuing with configuration"

        [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
        [System.Management.Automation.PSCredential ]$FarmCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointFarmAccountcreds.UserName)", $SharePointFarmAccountcreds.Password)
        [System.Management.Automation.PSCredential ]$SPsetupCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointSetupUserAccountcreds.UserName)", $SharePointSetupUserAccountcreds.Password)
        [System.Management.Automation.PSCredential]$SQLCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($SQLServiceCreds.UserName)", $SQLServiceCreds.Password)

        

        Import-DscResource -ModuleName  Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, SharePointDSC,xSQL

        Node localhost
        {

            LocalConfigurationManager
            {
                RebootNodeIfNeeded = $true
            }

            xWaitForADDomain DscForestWait
            {
                DomainName = $DomainName
                DomainUserCredential= $DomainCreds
                RetryCount = $RetryCount
                RetryIntervalSec = $RetryIntervalSec
            }

            xComputer DomainJoin
            {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $DomainCreds
                DependsOn = "[xWaitForADDomain]DscForestWait"
            }

            Group AddSetupUserAccountToLocalAdminsGroup
            {
                GroupName = "Administrators"
                Credential = $DomainCreds
                MembersToInclude = "${DomainName}\$($SharePointSetupUserAccountcreds.UserName)"
                Ensure="Present"
                DependsOn = "[xComputer]DomainJoin"
            }

            xADUser CreateFarmAccount
            {
                DomainAdministratorCredential = $DomainCreds
                DomainName = $DomainName
                UserName = $SharePointFarmAccountcreds.UserName
                Password =$FarmCreds
                Ensure = "Present"
                DependsOn = "[xComputer]DomainJoin"
            }
             xADUser createSPPOOL
            {
                DomainAdministratorCredential = $DomainCreds
                DomainName = $DomainName
                UserName = $SharePointSetupUserAccountcreds.UserName
                Password =$FarmCreds
                Ensure = "Present"
                DependsOn = "[xComputer]DomainJoin"
            }
             SPManagedAccount ServicePoolManagedAccount
        {
            AccountName          = $SharePointSetupUserAccountcreds.UserName
            Account              = $SPsetupCreds
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPCreateFarm]CreateSPFarm"
        }

            SPServiceAppPool MainServiceAppPool
        {
            Name                 = "SharePoint Service Applications"
            ServiceAccount       = $SPsetupCreds
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPCreateFarm]CreateSPFarm"
        }

            SPCreateFarm CreateSPFarm
        {
            DatabaseServer           = $DatabaseServer
            FarmConfigDatabaseName   = $DatabaseName
            Passphrase               = $SharePointFarmPassphrasecreds
            FarmAccount              = $FarmCreds
            CentralAdministrationPort = "5555"
            CentralAdministrationAuth = "NTLM"
            PsDscRunAsCredential     = $SPsetupCreds
            AdminContentDatabaseName = $AdministrationContentDatabaseName
            DependsOn                = "[xADUser]CreateFarmAccount", "[Group]AddSetupUserAccountToLocalAdminsGroup"
        }

            SPWebApplication WebApp
        {
            Name                   = $sharepointFarmName
            ApplicationPool        = $sharepointFarmName
            ApplicationPoolAccount = $SPsetupCreds
            AllowAnonymous         = $false
            AuthenticationMethod   = "NTLM"
            DatabaseName           = $contentDatabaseName
            Url                    = $SharepointWebfqdn
            Port                   = 80
            PsDscRunAsCredential   = $SPsetupCreds
            DependsOn              = "[SPManagedAccount]WebPoolManagedAccount"
         }
       

            
        }

}
function Get-NetBIOSName
{
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}
function DisableLoopbackCheck
{
    # See KB896861 for more information about why this is necessary.
    Write-Verbose -Message "Disabling Loopback Check ..."
    New-ItemProperty HKLM:\System\CurrentControlSet\Control\Lsa -Name 'DisableLoopbackCheck' -value '1' -PropertyType dword -Force | Out-Null
}
DisableLoopbackCheck 