#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration ConfigureSharePointServerHA
{

    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointSetupUserAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmAccountcreds,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SpServicePoolManagedAccountcreds,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SPWebPoolManagedAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmPassphrasecreds,

        [parameter(Mandatory)]
        [String]$DatabaseName,

        [parameter(Mandatory)]
        [String]$AdministrationContentDatabaseName,

        [parameter(Mandatory)]
        [String]$DatabaseServer,

        [parameter(Mandatory)]
        [String]$Configuration,

        [String]$SqlAlwaysOnAvailabilityGroupName,
        [String]$sharepointWebfqdn,
        [String]$sharepointFarmName,
        [String]$contentDatabaseName,
        
        [String[]]$DatabaseNames,

        [String]$PrimaryReplica,

        [String]$SecondaryReplica,

        [System.Management.Automation.PSCredential]$SQLServiceCreds,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60
    )

        Write-Verbose "AzureExtensionHandler loaded continuing with configuration"

        [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
        [System.Management.Automation.PSCredential ]$FarmCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointFarmAccountcreds.UserName)", $SharePointFarmAccountcreds.Password)
        [System.Management.Automation.PSCredential ]$SPsetupCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointSetupUserAccountcreds.UserName)", $SharePointSetupUserAccountcreds.Password)
         [System.Management.Automation.PSCredential ]$ServicePoolCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SpServicePoolManagedAccountcreds.UserName)", $SpServicePoolAccountcreds.Password)
          [System.Management.Automation.PSCredential ]$WebPoolCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SPWebPoolManagedAccountcreds.UserName)", $SPWebPoolManagedAccountcreds.Password)
        [System.Management.Automation.PSCredential]$SQLCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($SQLServiceCreds.UserName)", $SQLServiceCreds.Password)

        

        Import-DscResource -ModuleName  Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, xSharePoint, xSql

        Node localhost
        {

            LocalConfigurationManager
            {
                RebootNodeIfNeeded = $true
            }

            xWaitForADDomain DscForestWait
            {
                DomainName = $DomainName
                DomainUserCredential= $DomainCreds
                RetryCount = $RetryCount
                RetryIntervalSec = $RetryIntervalSec
            }

            xComputer DomainJoin
            {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $DomainCreds
                DependsOn = "[xWaitForADDomain]DscForestWait"
            }

            Group AddSetupUserAccountToLocalAdminsGroup
            {
                GroupName = "Administrators"
                Credential = $DomainCreds
                MembersToInclude = "${DomainName}\$($SharePointSetupUserAccountcreds.UserName)"
                Ensure="Present"
                DependsOn = "[xComputer]DomainJoin"
            }
            Group AddSetupUserAccountToLocalAdminsGroupSPPool
            {
                GroupName = "Administrators"
                Credential = $DomainCreds
                MembersToInclude = "${DomainName}\$($SpServicePoolManagedAccountcreds.UserName)"
                Ensure="Present"
                DependsOn = "[xComputer]DomainJoin"
            }
            Group AddSetupUserAccountToLocalAdminsGroupSPWebP
            {
                GroupName = "Administrators"
                Credential = $DomainCreds
                MembersToInclude = "${DomainName}\$($SPWebPoolManagedAccountcreds.UserName)"
                Ensure="Present"
                DependsOn = "[xComputer]DomainJoin"
            }

            xADUser CreateFarmAccount
            {
                DomainAdministratorCredential = $DomainCreds
                DomainName = $DomainName
                UserName = $SharePointFarmAccountcreds.UserName
                Password =$FarmCreds
                Ensure = "Present"
                DependsOn = "[xComputer]DomainJoin"
            }
             xADUser createSPPOOL
            {
                DomainAdministratorCredential = $DomainCreds
                DomainName = $DomainName
                UserName = $SpServicePoolManagedAccountcreds.UserName
                Password =$ServicePoolCreds
                Ensure = "Present"
                DependsOn = "[xComputer]DomainJoin"
            }
               xADUser WebPPOOL
            {
                DomainAdministratorCredential = $DomainCreds
                DomainName = $DomainName
                UserName = $WebPoolManagedAccountcreds.UserName
                Password =$WebPoolCreds
                Ensure = "Present"
                DependsOn = "[xComputer]DomainJoin"
            }
                   

         xSPCreateFarm CreateSPFarm
        {
            DatabaseServer           = $DatabaseServer
            FarmConfigDatabaseName   = $DatabaseName
            Passphrase               = $SharePointFarmPassphrasecreds
            FarmAccount              = $FarmCreds
            InstallAccount           = $SPsetupCreds
            CentralAdministrationPort = 5559
            AdminContentDatabaseName = $AdministrationContentDatabaseName
            DependsOn                = "[xADUser]CreateFarmAccount", "[Group]AddSetupUserAccountToLocalAdminsGroup"
        }
         xSPManagedAccount ServicePoolManagedAccount
        {
            AccountName          = $ServicePoolCreds.UserName
            Account              = $SpServicePoolManagedAccountcreds 
            InstallAccount = $SPsetupCreds
            DependsOn            = "[xSPCreateFarm]CreateSPFarm"
        }

        xSPManagedAccount WebPoolManagedAccount
        {
            AccountName          = $WebPoolCreds.UserName
            Account              = $SPWebPoolManagedAccountcreds
            InstallAccount = $SPsetupCreds
            DependsOn            = "[xSPCreateFarm]CreateSPFarm"
        }
         xSPDiagnosticLoggingSettings ApplyDiagnosticLogSettings
        {
            InstallAccount                        = $SPsetupCreds
            LogPath                                     = "C:\ULS"
            LogSpaceInGB                                = 5
            AppAnalyticsAutomaticUploadEnabled          = $false
            CustomerExperienceImprovementProgramEnabled = $true
            DaysToKeepLogs                              = 7
            DownloadErrorReportingUpdatesEnabled        = $false
            ErrorReportingAutomaticUploadEnabled        = $false
            ErrorReportingEnabled                       = $false
            EventLogFloodProtectionEnabled              = $true
            EventLogFloodProtectionNotifyInterval       = 5
            EventLogFloodProtectionQuietPeriod          = 2
            EventLogFloodProtectionThreshold            = 5
            EventLogFloodProtectionTriggerPeriod        = 2
            LogCutInterval                              = 15
            LogMaxDiskSpaceUsageEnabled                 = $true
            ScriptErrorReportingDelay                   = 30
            ScriptErrorReportingEnabled                 = $true
            ScriptErrorReportingRequireAuth             = $true
            DependsOn                                   = "[xSPCreateFarm]CreateSPFarm"
        }
        xSPUsageApplication UsageApplication 
        {
            Name                  = "Usage Service Application"
            DatabaseName          = "SP_Usage"
            UsageLogCutTime       = 5
            UsageLogLocation      = "C:\UsageLogs"
            UsageLogMaxFileSizeKB = 1024
            InstallAccount = $SPsetupCreds
            DependsOn             = "[xSPCreateFarm]CreateSPFarm"
        }
        xSPStateServiceApp StateServiceApp
        {
            Name                 = "State Service Application"
            DatabaseName         = "SP_State"
            InstallAccount = $SPsetupCreds
            DependsOn            = "[xSPCreateFarm]CreateSPFarm"
        }
        xSPDistributedCacheService EnableDistributedCache
        {
            Name                 = "AppFabricCachingService"
            Ensure               = "Present"
            CacheSizeInMB        = 1024
            ServiceAccount       = $ServicePoolCreds.UserName
            InstallAccount = $SPsetupCreds
            CreateFirewallRules  = $true
            DependsOn            = @('[xSPCreateFarm]CreateSPFarm','[xSPManagedAccount]ServicePoolManagedAccount')
        }

        xSPWebApplication SharePointSites
        {
            Name                   = "SharePoint Sites"
            ApplicationPool        = "SharePoint Sites"
            ApplicationPoolAccount = $SPWebPoolManagedAccount.UserName
            AllowAnonymous         = $false
            AuthenticationMethod   = "NTLM"
            DatabaseName           = "spfarm_Content"
            Url                    = $fqdn
            Port                   = 80
            InstallAccount   = $SPsetupCreds
            DependsOn              = "[xSPManagedAccount]WebPoolManagedAccount"
        }
        
        

       xSPServiceInstance ClaimsToWindowsTokenServiceInstance
        {  
            Name                 = "Claims to Windows Token Service"
            Ensure               = "Present"
            InstallAccount = $SPsetupCreds
            DependsOn            = "[xSPCreateFarm]CreateSPFarm"
        }   

        xSPServiceInstance SecureStoreServiceInstance
        {  
            Name                 = "Secure Store Service"
            Ensure               = "Present"
            InstallAccount = $SPsetupCreds
            DependsOn            = "[xSPCreateFarm]CreateSPFarm"
        }
        
        xSPServiceInstance SearchServiceInstance
        {  
            Name                 = "SharePoint Server Search"
            Ensure               = "Present"
            InstallAccount = $SPsetupCreds
            DependsOn            = "[xSPCreateFarm]CreateSPFarm"
        }
        
        #**********************************************************
        # Service applications
        #
        # This section creates service applications and required
        # dependencies
        #**********************************************************

        $serviceAppPoolName = "SharePoint Service Applications"
        xSPServiceAppPool MainServiceAppPool
        {
            Name                 = $serviceAppPoolName
            ServiceAccount       = $ServicePoolCreds.UserName
            InstallAccount = $SPsetupCreds
            DependsOn            = "[xSPCreateFarm]CreateSPFarm"
        }

        xSPSecureStoreServiceApp SecureStoreServiceApp
        {
            Name                  = "Secure Store Service Application"
            ApplicationPool       = $serviceAppPoolName
            AuditingEnabled       = $true
            AuditlogMaxSize       = 30
            DatabaseName          = "SP_SecureStore"
            InstallAccount  = $SPsetupCreds
            DependsOn             = "[xSPServiceAppPool]MainServiceAppPool"
        }
        
        xSPManagedMetaDataServiceApp ManagedMetadataServiceApp
        {  
            Name                 = "Managed Metadata Service Application"
            InstallAccount = $SPsetupCreds
            ApplicationPool      = $serviceAppPoolName
            DatabaseName         = "SP_MMS"
            DependsOn            = "[xSPServiceAppPool]MainServiceAppPool"
        }

        
        xSPSearchServiceApp SearchServiceApp
        {  
            Name                  = "Search Service Application"
            DatabaseName          = "SP_Search"
            ApplicationPool       = $serviceAppPoolName
            InstallAccount  = $SPsetupCreds
            DependsOn             = "[xSPServiceAppPool]MainServiceAppPool"
        }
                   
      <#
        xSPDatabaseAAG ConfigDBAAGContent
        {
            DatabaseName         = "SP_Content"
            AGName               =  $SqlAlwaysOnAvailabilityGroupName 
            InstallAccount = $SPsetupCreds
             DependsOn             = "[SPWebApplication]SharePointSites"
        }
         xSPDatabaseAAG ConfigDBAAGSTS
        {
            DatabaseName         = "SP_SecureStore"
            AGName               =  $SqlAlwaysOnAvailabilityGroupName             
            InstallAccount =$SPsetupCreds
             DependsOn             = "[SPSecureStoreServiceApp]SecureStoreServiceApp"
        }
          SPDatabaseAAG ConfigDBAAGusage
        {
            DatabaseName         = "SP_Usage"
            AGName               = "$SqlAlwaysOnAvailabilityGroupName"            
            InstallAccount = $SPsetupCreds
             DependsOn             = "[SPUsageApplication]UsageApplication"
        }
          SPDatabaseAAG ConfigDBAAGmms
        {
            DatabaseName         = "SP_MMS"
            AGName               =  $SqlAlwaysOnAvailabilityGroupName          
            InstallAccount = $SPsetupCreds
             DependsOn             = "[SPManagedMetaDataServiceApp]ManagedMetadataServiceApp"
        }
        SPDatabaseAAG ConfigDBAAGstate
        {
            DatabaseName         = "SP_State"
            AGName               =  $SqlAlwaysOnAvailabilityGroupName            
            InstallAccount = $SPsetupCreds
             DependsOn             = "[SPStateServiceApp]StateServiceApp"
        }
        SPDatabaseAAG Configsearch
        {
            DatabaseName         = "SP_Search"
            AGName               =  $SqlAlwaysOnAvailabilityGroupName          
            InstallAccount = $SPsetupCreds
             DependsOn             = "[SPStateServiceApp]SearchServiceApp"
        }
        
        SPDatabaseAAG Configadmin
        {
            DatabaseName         = $AdministrationContentDatabaseName
            AGName               = $SqlAlwaysOnAvailabilityGroupName            
            InstallAccount = $SPsetupCreds
             DependsOn             = "[SPCreateFarm]CreateSPFarm"
        }
        #>

         xSqlNewAGDatabase SQLAGDatabases
            {
                SqlAlwaysOnAvailabilityGroupName = $SqlAlwaysOnAvailabilityGroupName
                DatabaseNames = $DatabaseNames
                PrimaryReplica = $PrimaryReplica
                SecondaryReplica = $SecondaryReplica
                SqlAdministratorCredential = $SQLCreds
            }
            
        }

}
function Get-NetBIOSName
{
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}




function DisableLoopbackCheck
{
    # See KB896861 for more information about why this is necessary.
    Write-Verbose -Message "Disabling Loopback Check ..."
    New-ItemProperty HKLM:\System\CurrentControlSet\Control\Lsa -Name 'DisableLoopbackCheck' -value '1' -PropertyType dword -Force | Out-Null
}
DisableLoopbackCheck 

function Update-SPFailOverInstance
{
    param(
        [Parameter(Mandatory=$true)]
        [string]$DatabaseName
    )

    try
    {
        Get-SPDatabase | ForEach-Object
        {
            If ($_.Name -eq $DatabaseName)
            {
                $_.AddFailoverServiceInstance($FailoverServerInstance)
                $_.Update()
                Write-Verbose -Message "Updated database failover instance for '$($_.Name)'."
            }
        }
    }
    catch
    {
            Write-Verbose -Message "FAILED: Updating database failover instance for '$($_.Name)'."
    }
}