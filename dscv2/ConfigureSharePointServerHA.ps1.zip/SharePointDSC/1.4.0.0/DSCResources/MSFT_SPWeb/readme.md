**Description**

This resource will provision a SPWeb based on the settings that are passed through. 
These settings map to the New-SPWeb cmdlet and accept the same values and types. 
