**Description**

This resource will deploy and configure a content source in a specified search service application.
